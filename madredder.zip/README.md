# GK1---Innovation
Godkendelsesopgave 1 - Innovation og ny teknologi
